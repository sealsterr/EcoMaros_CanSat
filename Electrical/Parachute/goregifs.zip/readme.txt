PRINTING OUT THE GORE PATTERN (.gif format)

There are probably a number of different software packages that can be
used to print out the gore patterns. I find that MS EXCEL works well
for this purpose and is simple to do.

The first step is to unzip the ".zip" file.
Use WINZIP for this purpose.
WINZIP will allow you to extract the .gif files. These are graphic
format files. 
 
In EXCEL, choose Insert/Picture/From file, then choose the appropriate
gif file. This will bring the graphics file into the spreadsheet.
 
Next, simply choose File/Print to print out the pattern. 
It will come out on a number of sheets. 

Assemble the pattern, then measure and compare the printed size 
to the "Actual pattern size" shown on the pattern. 
If it is different, simply scale it by choosing File/Page setup
and set the Scale as required.
This will be the ratio of "Actual pattern size" divided by the printed
pattern size that you measured.

Reprint the pattern, and check to confirm that the printed pattern is
in fact the correct size.
 

